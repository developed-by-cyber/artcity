export { default as Navbar } from "./Navbar/Navbar";
export { default as Header } from "./Header/Header";
export { default as Slider } from "./Slider/Slider";
export { default as Subscribe } from "./Subscribe/Subscribe";
export { default as Footer } from "./Footer/Footer";
export { default as Explore } from "./Explore/Explore";
export { default as Collection1 } from "./Collection1/Collection";
export { default as Collection2 } from "./Collection2/Collection";
