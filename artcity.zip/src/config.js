const domain = 'https://artcity.tech'
export {domain}